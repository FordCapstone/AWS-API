def db_get_where(conn, table, columns=[], values=[]):
    """
    Gets all rows from the specified table that match the given conditions.
    The columns and values lists should be the same length.
    Returns all the rows formatted as JSON.
    """
    # Format the SELECT constraints
    constr = list(zip(columns, values))
    pairs = len(constr)

    # Construct the query string
    query_str = f"SELECT * FROM {table}"
    if pairs > 0:
        # Construct the WHERE constraints
        query_str = query_str + " WHERE " + " AND ".join([" = ".join([t[0], f"'{str(t[1])}'" if isinstance(t[1], str) else str(t[1])]) for t in constr]) + ";"
    else:
        # No constraints, get all rows
        query_str = query_str + ";"

    return query_str